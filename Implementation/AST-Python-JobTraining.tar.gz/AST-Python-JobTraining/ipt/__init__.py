# -*- coding: utf-8 -*-
"""
__init__.py file for ipt package
Bryan S. Graham, UC - Berkeley
bgraham@econ.berkeley.edu
16 May 2016
"""

# Import the different functions into the package
#from ols import ols
from logit import logit
from att import att